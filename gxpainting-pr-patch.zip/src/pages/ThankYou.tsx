export default function ThankYou() {
  const params = new URLSearchParams(location.search)
  const utm = Object.fromEntries(params.entries())
  return (
    <main className="container" style={{paddingTop:'3rem'}}>
      <h1>Thanks! We’ll be in touch.</h1>
      <p>We’ve received your request. Here are your tracking details:</p>
      <pre style={{background:'#f6f6f6',padding:'1rem',borderRadius:8,overflowX:'auto'}}>
        {JSON.stringify(utm, null, 2)}
      </pre>
      <p><a className="btn" href="/">Back to home</a></p>
    </main>
  )
}