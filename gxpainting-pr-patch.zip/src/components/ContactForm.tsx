import { useEffect, useRef, useState } from 'react'

declare global {
  interface Window {
    gtag?: (...args: any[]) => void
    plausible?: (eventName: string, opts?: Record<string, any>) => void
    turnstile?: any
  }
}

export default function ContactForm() {
  const [pending, setPending] = useState(false)
  const [err, setErr] = useState<string | null>(null)
  const widgetRef = useRef<HTMLDivElement | null>(null)
  const [token, setToken] = useState<string>('')

  // Load Turnstile script dynamically (no index.html change needed)
  useEffect(() => {
    const existing = Array.from(document.scripts).some(s => s.src.includes('turnstile/v0/api.js'))
    if (!existing) {
      const s = document.createElement('script')
      s.src = 'https://challenges.cloudflare.com/turnstile/v0/api.js'
      s.async = true
      s.defer = true
      document.head.appendChild(s)
    }
  }, [])

  // Render / reset Turnstile widget
  useEffect(() => {
    const siteKey = import.meta.env.VITE_TURNSTILE_SITE_KEY
    const render = () => {
      if (widgetRef.current && window.turnstile && siteKey) {
        try { window.turnstile.remove(widgetRef.current) } catch {}
        window.turnstile.render(widgetRef.current, {
          sitekey: siteKey,
          callback: (t: string) => setToken(t),
          'refresh-expired': 'auto',
          appearance: 'interaction-only'
        })
      }
    }
    if (window.turnstile) render()
    const id = window.setInterval(() => { if (window.turnstile) { window.clearInterval(id); render() } }, 300)
    return () => window.clearInterval(id)
  }, [])

  function validateEmail(v: string) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)
  }

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setErr(null)
    window.gtag?.('event','lead_submitted'); window.plausible?.('lead_submitted')

    const fd = new FormData(e.currentTarget)
    const name = (fd.get('name') || '').toString().trim()
    const email = (fd.get('email') || '').toString().trim()
    const phone = (fd.get('phone') || '').toString().trim()
    const service = (fd.get('service') || '').toString().trim()
    const message = (fd.get('message') || '').toString().trim()

    if (!name) return setErr('Name is required')
    if (!validateEmail(email)) return setErr('Valid email required')
    if (!service) return setErr('Please select a service')
    if (!message) return setErr('Please tell us a bit about the project')
    if (!token) return setErr('Please complete the captcha.')

    setPending(true)
    try {
      const res = await fetch('/.netlify/functions/mail', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          name, email, phone: phone || undefined, service, message,
          sourceUrl: window.location.href,
          utm: Object.fromEntries(new URLSearchParams(window.location.search)),
          turnstileToken: token
        })
      })
      const json = await res.json()
      if (res.ok && json?.ok) {
        window.gtag?.('event','lead_sent'); window.plausible?.('lead_sent')
        await new Promise(r => setTimeout(r, 150))
        const q = new URLSearchParams(window.location.search)
        window.location.assign(`/thank-you?${q.toString()}`)
      } else {
        setErr(json?.code ? `Submission blocked: ${json.code}` : 'Something went wrong. Please try again.')
        window.plausible?.('lead_blocked'); window.gtag?.('event','lead_blocked', { reason: json?.code || 'unknown' })
      }
    } catch {
      setErr('Network error. Please try again.')
    } finally {
      setPending(false)
      try { if (window.turnstile && widgetRef.current) window.turnstile.reset(widgetRef.current) } catch {}
    }
  }

  return (
    <form onSubmit={handleSubmit} style={{ display: 'grid', gap: '0.75rem' }}>
      <div><label>Name</label><br /><input name="name" type="text" required placeholder="Jane Doe" /></div>
      <div><label>Email</label><br /><input name="email" type="email" required placeholder="jane@example.com" /></div>
      <div><label>Phone (optional)</label><br /><input name="phone" type="tel" placeholder="(555) 555-5555" /></div>
      <div><label>Service</label><br />
        <select name="service" defaultValue="" required>
          <option value="" disabled>Select a service</option>
          <option value="interior">Interior painting</option>
          <option value="exterior">Exterior painting</option>
          <option value="cabinet">Cabinet refinishing</option>
          <option value="deck">Deck/fence staining</option>
          <option value="drywall">Drywall/patching</option>
          <option value="other">Other</option>
        </select>
      </div>
      <div><label>Message</label><br /><textarea name="message" required rows={5} placeholder="Tell us about your project..." /></div>
      <div ref={widgetRef} /> {/* Turnstile */}
      {err && <div style={{ background:'#fee', color:'#900', border:'1px solid #fbb', padding:'.6rem .7rem', borderRadius:8 }}>{err}</div>}
      <button type="submit" disabled={pending} className="btn">{pending ? 'Sending…' : 'Send request'}</button>
    </form>
  )
}