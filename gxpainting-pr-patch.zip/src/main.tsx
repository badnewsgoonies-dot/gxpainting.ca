import React from 'react'
import ReactDOM from 'react-dom/client'
import Analytics from './analytics'
import App from './App'
import ThankYou from './pages/ThankYou'
import './styles.css'

const path = window.location.pathname
const Screen = path === '/thank-you' ? <ThankYou /> : <App />

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <Analytics />
    {Screen}
  </React.StrictMode>
)