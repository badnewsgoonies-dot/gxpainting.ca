import ContactForm from './components/ContactForm'

export default function App() {
  const scrollToContact = () => {
    document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }

  return (
    <>
      <div className="hero-wrap">
        <header className="container" style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'1rem'}}>
          <div style={{fontWeight:800,letterSpacing:'.3px'}}>GX Painting</div>
          <nav style={{display:'flex',gap:'.75rem'}}>
            <a className="btn secondary" href="#services">Services</a>
            <button className="btn" onClick={scrollToContact}>Get a free quote</button>
          </nav>
        </header>

        <section className="container hero" aria-labelledby="hero-title">
          <div>
            <h1 id="hero-title">Premium interior & exterior painting across the GTA</h1>
            <p className="lede">Fast quotes, clean workmanship, and durable finishes. Cabinets, drywall repair, decks & fences—done right.</p>
            <div className="hero-cta">
              <button className="btn" onClick={scrollToContact}>Get a free quote</button>
              <a className="btn secondary" href="tel:+1647XXXXXXX" aria-label="Call GX Painting now">Call now</a>
            </div>

            <div className="features">
              <div className="feature"><div className="icon">🧼</div><div><strong>Spotless cleanup</strong><div className="muted">We treat your home like our own.</div></div></div>
              <div className="feature"><div className="icon">🕒</div><div><strong>On-time & on-budget</strong><div className="muted">Clear timelines and daily updates.</div></div></div>
              <div className="feature"><div className="icon">🛡️</div><div><strong>Top-quality paints</strong><div className="muted">Low-VOC options available.</div></div></div>
            </div>
          </div>

          <div className="hero-card" aria-hidden="true">
            <div style={{display:'grid',gap:'.5rem'}}>
              <div style={{fontWeight:700}}>Recent projects</div>
              <div className="muted">A snapshot of finishes we deliver.</div>
              <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'.5rem'}}>
                <div style={{background:'#eefaf2',borderRadius:10,aspectRatio:'4/3'}}></div>
                <div style={{background:'#f0f9ff',borderRadius:10,aspectRatio:'4/3'}}></div>
                <div style={{background:'#fff7ed',borderRadius:10,aspectRatio:'4/3'}}></div>
                <div style={{background:'#fef2f2',borderRadius:10,aspectRatio:'4/3'}}></div>
              </div>
            </div>
          </div>
        </section>
      </div>

      <main className="container">
        <section id="services" className="section" aria-labelledby="services-title">
          <h2 id="services-title">Our services</h2>
          <p className="muted">From a single room to whole-home repaints, inside and out.</p>

          <div className="services-grid" role="list">
            <article className="card" role="listitem"><div>🎨</div><h3>Interior Painting</h3><p>Walls, ceilings, trim & doors. Crisp lines and uniform coverage.</p></article>
            <article className="card" role="listitem"><div>🏠</div><h3>Exterior Painting</h3><p>Stucco, siding, brick, and trim with weather-resistant systems.</p></article>
            <article className="card" role="listitem"><div>🗄️</div><h3>Cabinet Refinishing</h3><p>Factory-like finishes using durable catalyzed coatings.</p></article>
            <article className="card" role="listitem"><div>🧱</div><h3>Drywall & Patching</h3><p>Repairs, texture matching, and seamless repaints.</p></article>
            <article className="card" role="listitem"><div>🪵</div><h3>Decks & Fences</h3><p>Staining and protective finishes for outdoor wood.</p></article>
            <article className="card" role="listitem"><div>🏢</div><h3>Commercial</h3><p>Flexible hours and clean job sites for offices & retail.</p></article>
          </div>
        </section>

        <section id="contact" className="section" aria-labelledby="contact-title">
          <h2 id="contact-title">Get a free quote</h2>
          <p className="muted">Tell us about your project and we’ll respond quickly.</p>
          <ContactForm />
        </section>
      </main>
    </>
  )
}