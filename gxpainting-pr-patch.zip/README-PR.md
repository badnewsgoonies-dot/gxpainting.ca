# PR Drop-in — GX Painting (hero + services + contact + analytics)

**Add these files to your repo** at the exact paths below. Then update `package.json` dependencies using the included `package.json.additions.json`.

## Files to add

- `netlify/functions/mail.js`
- `src/components/ContactForm.tsx`
- `src/pages/ThankYou.tsx`
- `src/analytics.tsx`
- `src/styles.css`
- `src/main.tsx`  (replace your existing main.tsx with this one)
- `src/App.tsx`   (replace your landing page file with this one, if named differently paste content accordingly)
- `public/robots.txt`
- `public/sitemap.xml`
- `package.json.additions.json` (helper file — copy deps into your package.json)

## After uploading the files

1. Open **package.json** in GitHub → add these dependencies:
   ```json
   "@upstash/ratelimit": "^1.0.2",
   "@upstash/redis": "^1.28.4",
   "resend": "^3.4.0"
   ```
   *(Merge them under `"dependencies"` — keep the rest of your file unchanged.)*

2. In **Netlify → Site settings → Environment**, add:
   - `RESEND_API_KEY`
   - `TURNSTILE_SECRET_KEY`
   - `UPSTASH_REDIS_REST_URL`
   - `UPSTASH_REDIS_REST_TOKEN`
   - `LEAD_TO_EMAILS=leads@gxpainting.ca`
   - `SITE_ENV=production`
   - `VITE_TURNSTILE_SITE_KEY` (client; safe to expose)
   - (optional) `VITE_GA4_ID`, `VITE_PLAUSIBLE_DOMAIN`

3. Deploy the site. Then test:
   - Submit the form → check function logs and your `leads@gxpainting.ca` inbox.
   - In Gmail “Show original”: SPF/DKIM should be PASS (once Resend domain verified).

## Notes
- The form dynamically loads the Turnstile script — no `index.html` change needed.
- `/thank-you` is handled without react-router; we render a ThankYou screen when `location.pathname === '/thank-you'`.
- Rate limits: 5/min IP, 300/day IP (adjust inside `netlify/functions/mail.js` if needed).