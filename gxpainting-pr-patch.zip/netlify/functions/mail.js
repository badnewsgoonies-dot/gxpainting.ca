// /.netlify/functions/mail
// CommonJS-style Netlify Function with Turnstile verify + Upstash ratelimit + Resend email
const { Resend } = require('resend')
const { Ratelimit } = require('@upstash/ratelimit')
const { Redis } = require('@upstash/redis')

const resend = new Resend(process.env.RESEND_API_KEY)
const redis = new Redis({
  url: process.env.UPSTASH_REDIS_REST_URL,
  token: process.env.UPSTASH_REDIS_REST_TOKEN
})
const rlMin = new Ratelimit({ redis, limiter: Ratelimit.fixedWindow(5, '1 m') })
const rlDayIp = new Ratelimit({ redis, limiter: Ratelimit.fixedWindow(300, '1 d') })

async function verifyTurnstile(token, ip) {
  const r = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', {
    method: 'POST',
    headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      secret: process.env.TURNSTILE_SECRET_KEY,
      response: token,
      remoteip: ip || ''
    })
  })
  const json = await r.json()
  return !!json.success
}

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return resp(405, { ok:false, code:'method' })
  }

  const ip = (event.headers['x-forwarded-for'] || '').split(',')[0] || '0.0.0.0'

  let body
  try { body = JSON.parse(event.body || '{}') }
  catch { return resp(400, { ok:false, code:'badjson' }) }

  const { name, email, phone, message, service, sourceUrl, utm, turnstileToken } = body || {}
  if (!name || !email || !message || !service || !turnstileToken) {
    return resp(400, { ok:false, code:'validation' })
  }

  // Captcha
  const okCaptcha = await verifyTurnstile(turnstileToken, ip)
  if (!okCaptcha) return resp(401, { ok:false, code:'captcha' })

  // Rate limits
  const [m, d] = await Promise.all([rlMin.limit(`ip:${ip}`), rlDayIp.limit(`ip:${ip}:d`)])
  if (!m.success || !d.success) return resp(429, { ok:false, code:'ratelimit' })

  // Send email via Resend
  const { data, error } = await resend.emails.send({
    from: 'GX Painting <hello@mail.gxpainting.ca>',
    to: (process.env.LEAD_TO_EMAILS || '').split(',').filter(Boolean),
    subject: `New lead: ${service}`,
    reply_to: email,
    text: [
      `Name: ${name}`,
      `Email: ${email}`,
      `Phone: ${phone || '-'}`,
      `Service: ${service}`,
      `Message:`,
      message,
      `---`,
      `Source: ${sourceUrl || '-'}`,
      `UTM: ${JSON.stringify(utm || {})}`,
      `IP: ${ip}`
    ].join('\n')
  })

  if (error) return resp(500, { ok:false, code:'send' })
  return resp(200, { ok:true, id: data?.id })
}

function resp(status, body) {
  return {
    statusCode: status,
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body)
  }
}